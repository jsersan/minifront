export const environment = {
    production: true,
    apiUrl: '/api'  // o la URL de producción adecuada
  };